# Kallimni · كلّمني — Egyptian Arabic for the Rabbit R1

A standalone Rabbit R1 Creation for beginner **Egyptian Arabic** (Masri, not just MSA): five-minute daily lessons, flashcards, quizzes, pronunciation playback, and an optional soft background nasheed player.

Independent project — no dependency on Atlas or any backend, login, or paid API. Plain HTML/CSS/JS, no build step.

## What's in it

| Feature | How it works |
|---|---|
| 3 lessons, 27 phrases | Greetings · Polite Basics · Introductions. Arabic script, transliteration, English, usage notes (incl. masculine/feminine forms). |
| 5-minute flow | Learn (browse + listen) → Flashcards (reveal, Again / Got it) → 6-question quiz (both directions) → result. Timer in the top bar turns orange past 5:00. |
| Daily lesson | Home picks the next unfinished lesson; once all are done it picks the weakest for review. Day streak + "learned" count. |
| Pronunciation | Plays example audio only — never listens, never scores. Order: bundled recording (`audio/`) → device Arabic voice (ar-EG preferred) → optional "R1 voice" (Settings, off by default). |
| Nasheed player | ♪ button: on/off, play/pause, prev/next, volume. Lowers (or pauses — your choice) while Arabic plays, then returns to your volume. Preference saved. Only plays playlist entries that carry license info. |
| Progress | Saved to the R1's `creationStorage.plain` (Base64, as the SDK requires); falls back to `localStorage` in a browser. |
| Controls | Touch everywhere, plus R1 hardware: wheel ↕ browse / select / volume, side button = main action, hold side = play Arabic (on Home: music on/off). |

## Preview locally

```bash
cd kallimni
python3 -m http.server 8000
```

Open <http://localhost:8000> in Chrome, open DevTools → device toolbar, set **240 × 282**. Keyboard stands in for the hardware: **↑/↓** = wheel, **Enter/Space** = side button, **P** = hold side.

Pronunciation in desktop Chrome uses whatever Arabic voice your OS has (Windows: add an Arabic speech pack under Settings → Time & language → Speech).

## Run the tests

```bash
python3 tests/r1_emulation_test.py
```

Headless Chromium at 240×282 with stubs for `creationStorage` (rejects non-Base64), `PluginMessageHandler`, R1 hardware events and a fake Arabic voice; a test-only tone stands in for music. Screenshots go to `tests/screenshots/`. Current result: **39/39 checks pass**.

## Install on the R1 (only when you're ready — needs your approval)

R1 Creations are installed from a **hosted HTTPS URL** via a QR code; there is no sideload-from-file path. Nothing has been hosted or installed.

1. Host the `kallimni/` folder on any static HTTPS host (GitHub Pages, Netlify drop, Cloudflare Pages — free tiers are fine). You can leave out `tests/` and `install/`.
2. Open `install/qr.html` in a desktop browser, paste the hosted URL, click **Make QR**. It encodes the same JSON fields as Rabbit's official generator (`title`, `url`, `description`, `iconUrl`, `themeColor`). Alternatively paste the shown JSON into Rabbit's own QR tool.
3. On the R1, open the Creations QR scanner (camera) and scan.
4. After updating files, bump **Version** in `install/qr.html` and rescan — the R1 caches Creation URLs.

**Privacy note:** a public static host makes the files publicly reachable. They contain no personal data; your progress stays on the device.

## On-device checklist (not yet verified — needs your R1)

I could only test in an emulator. On the device, please check:

- [ ] Layout fits the screen; Arabic renders with correct shaping.
- [ ] Wheel, side click, and hold-side behave as described (hold may be intercepted by rabbitOS's own push-to-talk — if so, use the on-screen 🔊).
- [ ] **Settings** shows whether a device Arabic voice exists. If "none", pronunciation needs recordings in `audio/` or the experimental R1 voice.
- [ ] Progress survives closing and reopening the Creation.
- [ ] With a licensed track added: music starts after a tap, volume buttons work, music lowers during 🔊 and returns afterwards.
- [ ] What happens to music when the screen sleeps or you leave the Creation (expected: it stops; see below).

## Known limitations

- **No nasheeds bundled.** I couldn't verify a license for any specific recording, so the playlist is empty and the panel says so. Add tracks per `music/README.md` (your own recordings, CC0/public domain, CC BY with attribution, or written permission).
- **Background audio:** music only plays while Kallimni is open on screen. Kallimni pauses it when the Creation is hidden; screen sleep or leaving the Creation will stop it, and it resumes on return. It's study background music, not a system-wide player.
- **Autoplay:** the WebView requires a tap before audio can start. Your on/off preference is remembered; music resumes on your first tap after opening.
- **Pronunciation accuracy:** Arabic TTS voices are mostly Modern Standard Arabic; Egyptian sounds (hard *g*, dropped *q*) may come out MSA-style. The app warns once. Native recordings (`audio/README.md`) are the real fix.
- **Experimental R1 voice** (off by default) asks rabbitOS's cloud assistant to read the phrase. It needs internet, may paraphrase or mispronounce, and gives no "finished" signal, so music ducking uses a timed estimate.
- **No speech recognition or pronunciation scoring**, by design.
- `install/qr.html` loads its QR library from cdnjs, so it needs internet when you open it.

## Adding lessons

Append an object to `KALLIMNI_LESSONS` in `js/lessons.js` (format documented at the top of that file). Home, flashcards, quiz, and progress pick it up automatically. Keep phrase `id`s unique and stable — progress is saved against them.

## Files

```
index.html          app shell (240×282)
css/app.css         navy / orange / cyan theme
js/lessons.js       lesson content + transliteration key
js/app.js           screens, lesson flow, settings
js/speech.js        pronunciation playback (no listening)
js/music.js         nasheed player + ducking
js/storage.js       creationStorage (Base64) / localStorage adapter
js/hardware.js      R1 wheel + side-button events
music/playlist.js   licensed tracks only (empty)
audio/              optional native recordings
icon.png            Creation icon
install/qr.html     local QR generator for installation
tests/              emulator test + screenshots
```

API names follow Rabbit's official `rabbit-hmi-oss/creations-sdk` (plugin-demo `creation-triggers.md`): `sideClick`, `longPressStart/End`, `scrollUp/Down`, `window.creationStorage.plain`, `PluginMessageHandler.postMessage` with `wantsR1Response`, `window.onPluginMessage`.
