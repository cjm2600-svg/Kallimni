import unittest, json, pathlib, subprocess, sys, tempfile, shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]
class CatalogTests(unittest.TestCase):
    def test_candidates(self):
        from draft import validate
        candidates=json.loads((ROOT/'agent/candidates.json').read_text())
        for item in candidates: validate(item)
        self.assertEqual(len({x['id'] for x in candidates}),len(candidates))
    def test_catalog(self):
        catalog=json.loads((ROOT/'lessons/catalog.json').read_text())
        self.assertIsInstance(catalog['version'],int)
        self.assertIsInstance(catalog['lessons'],list)
    def test_draft_is_idempotent_and_bounded(self):
        with tempfile.TemporaryDirectory() as d:
            temp=pathlib.Path(d)
            (temp/'agent').mkdir(); (temp/'lessons').mkdir()
            for name in ['draft.py','candidates.json']:
                shutil.copy2(ROOT/'agent'/name,temp/'agent'/name)
            shutil.copy2(ROOT/'lessons/catalog.json',temp/'lessons/catalog.json')
            for _ in range(4):
                subprocess.run([sys.executable,str(temp/'agent/draft.py')],check=True,capture_output=True)
            c=json.loads((temp/'lessons/catalog.json').read_text())
            self.assertEqual(len(c['lessons']),2)
            self.assertEqual(c['version'],3)
if __name__=='__main__': unittest.main()
