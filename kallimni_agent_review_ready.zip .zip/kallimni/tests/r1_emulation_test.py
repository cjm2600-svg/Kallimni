"""
R1 emulation test for Kallimni.

Runs the Creation in Chromium at 240x282 with:
  - a window.creationStorage.plain stub that REJECTS non-Base64 values
  - PluginMessageHandler stub that records posted messages
  - R1 hardware events (sideClick / scrollUp / scrollDown / longPressStart)
  - a fake Arabic speechSynthesis voice (so ducking can be observed)
  - a TEST-ONLY tone track injected as the playlist (not shipped)

Usage:  python3 tests/r1_emulation_test.py   (from the kallimni folder)
Screenshots land in tests/screenshots/.
"""
import base64, http.server, os, socketserver, sys, threading, time
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOTS = os.path.join(ROOT, "tests", "screenshots")
os.makedirs(SHOTS, exist_ok=True)

class Quiet(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=ROOT, **k)
    def log_message(self, *a): pass

srv = socketserver.TCPServer(("127.0.0.1", 0), Quiet)
PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = f"http://127.0.0.1:{PORT}/index.html"

R1_STUBS = r"""
(() => {
  const isB64 = s => typeof s === "string" && /^[A-Za-z0-9+/]*={0,2}$/.test(s) && s.length % 4 === 0;
  const persisted = JSON.parse(sessionStorage.getItem("__r1store") || "{}");
  window.__r1 = { posted: [], badWrites: 0 };
  window.creationStorage = { plain: {
    setItem: (k, v) => new Promise((res, rej) => {
      if (!isB64(v)) { window.__r1.badWrites++; return rej(new Error("not base64")); }
      persisted[k] = v; sessionStorage.setItem("__r1store", JSON.stringify(persisted)); res();
    }),
    getItem: k => Promise.resolve(k in persisted ? persisted[k] : null),
    removeItem: k => { delete persisted[k]; sessionStorage.setItem("__r1store", JSON.stringify(persisted)); return Promise.resolve(); },
    clear: () => Promise.resolve()
  }};
  window.PluginMessageHandler = { postMessage: m => window.__r1.posted.push(JSON.parse(m)) };

  // Fake Arabic TTS voice: "speaks" for 600 ms.
  if (window.__fakeVoice !== false) {
    const voice = { name: "Test Arabic", lang: "ar-EG", default: false, localService: true, voiceURI: "t" };
    window.__spoken = [];
    const synth = {
      getVoices: () => [voice],
      addEventListener: () => {},
      cancel: () => {},
      speak: u => { window.__spoken.push(u.text); setTimeout(() => u.onstart && u.onstart(), 30);
                    setTimeout(() => u.onend && u.onend(), 600); }
    };
    Object.defineProperty(window, "speechSynthesis", { value: synth, configurable: true });
    window.SpeechSynthesisUtterance = function (t) { this.text = t; };
  }
})();
"""

TEST_PLAYLIST = """window.KALLIMNI_PLAYLIST = [
 { title: "Test tone A", artist: "Test", src: "tests/fixtures/test-tone.mp3", license: "test-only", source: "generated" },
 { title: "Test tone B", artist: "Test", src: "tests/fixtures/test-tone.mp3", license: "test-only", source: "generated" },
 { title: "No license (must be ignored)", src: "x.mp3" }
];"""

results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail and not cond else ""))

def hw(page, ev):
    page.evaluate(f"window.dispatchEvent(new Event('{ev}'))")
    page.wait_for_timeout(120)

def shot(page, name):
    page.screenshot(path=os.path.join(SHOTS, name + ".png"))

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path="/usr/bin/chromium", args=["--no-sandbox"])
    ctx = browser.new_context(viewport={"width": 240, "height": 282}, device_scale_factor=2, has_touch=True)
    ctx.add_init_script(R1_STUBS)
    ctx.route("**/music/playlist.js", lambda r: r.fulfill(status=200, content_type="application/javascript", body=TEST_PLAYLIST))
    page = ctx.new_page()
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: m.type == "error" and errors.append(m.text))

    page.goto(URL); page.wait_for_timeout(500)
    shot(page, "01-home")

    # Layout fits 240x282 without page overflow
    dims = page.evaluate("[document.documentElement.scrollWidth, document.documentElement.scrollHeight]")
    check("layout fits 240x282", dims[0] <= 240 and dims[1] <= 282, str(dims))
    check("three lessons listed", page.locator(".lesson").count() == 3)
    check("storage backend is R1 creationStorage", page.evaluate("KStore.backend") == "r1")

    # Hardware: scroll to focus, side click to open 'Today's lesson'
    hw(page, "scrollDown")
    check("scroll wheel moves focus on home", page.locator(".today.focus").count() == 1)
    hw(page, "sideClick")
    check("side click opens today's lesson (Greetings)", "Greetings" in page.inner_text("#barTitle"))
    check("Arabic + transliteration + English shown",
          page.inner_text(".ar") == "السلام عليكم" and "salaamu" in page.inner_text(".tr") and "Peace" in page.inner_text(".en"))
    check("lesson timer visible", page.is_visible("#timer"))
    shot(page, "02-learn")

    # Wheel navigation through phrases
    hw(page, "scrollDown"); hw(page, "scrollDown")
    check("wheel down advances phrases", page.inner_text(".step").startswith("3/"))
    hw(page, "scrollUp")
    check("wheel up goes back", page.inner_text(".step").startswith("2/"))

    # Pronunciation via side click (fake ar-EG voice)
    hw(page, "sideClick"); page.wait_for_timeout(100)
    check("side click plays pronunciation via TTS", page.evaluate("window.__spoken.slice(-1)[0]") == "وعليكم السلام")

    # ---- Music: start, then duck during speech, restore after ----
    page.click("#musicBtn"); page.wait_for_timeout(200)
    shot(page, "03-music-panel")
    check("unlicensed playlist entry ignored", page.evaluate("KMusic.state.count") == 2)
    page.click("#en"); page.wait_for_timeout(800)
    st = page.evaluate("KMusic.state")
    check("music on after tap", st["enabled"] and st["playing"], str(st))
    page.click("#vd"); page.wait_for_timeout(200)  # 0.30 -> 0.25
    check("volume down works", abs(page.evaluate("KMusic.state.volume") - 0.25) < 1e-6)
    hw(page, "scrollUp"); page.wait_for_timeout(200)  # wheel in panel: +5%
    check("wheel adjusts volume in music panel", abs(page.evaluate("KMusic.state.volume") - 0.30) < 1e-6)
    shot(page, "04-music-playing")

    # back to lesson; play phrase; observe duck
    page.click("#backBtn"); page.wait_for_timeout(150)
    check("back returns to the same lesson card", page.inner_text(".step").startswith("2/"))
    page.click("#play"); page.wait_for_timeout(330)
    v_during = page.evaluate("KMusic._audio.volume")
    check("music lowered while Arabic plays", v_during < 0.1, f"vol={v_during:.3f}")
    check("music icon shows ducked", page.locator("#musicBtn.ducked").count() == 1)
    page.wait_for_timeout(1200)
    v_after = page.evaluate("KMusic._audio.volume")
    check("previous volume restored after pronunciation", abs(v_after - 0.30) < 0.02, f"vol={v_after:.3f}")

    # pause-mode ducking
    page.evaluate("KMusic.setDuckMode('pause')")
    page.click("#play"); page.wait_for_timeout(350)
    check("pause mode: music paused during Arabic", page.evaluate("KMusic._audio.paused"))
    page.wait_for_timeout(1300)
    check("pause mode: music resumes after Arabic", not page.evaluate("KMusic._audio.paused"))
    page.evaluate("KMusic.setDuckMode('lower')")

    # user pause stays paused across speech
    page.evaluate("KMusic.pause()"); page.click("#play"); page.wait_for_timeout(1200)
    check("user-paused music is not restarted by speech", page.evaluate("KMusic._audio.paused"))
    page.evaluate("KMusic.play()"); page.wait_for_timeout(300)

    # ---- finish learn -> flashcards ----
    for _ in range(10): hw(page, "scrollDown")
    check("reached flashcards", "Cards" in page.inner_text("#barTitle"))
    shot(page, "05-flash-front")
    hw(page, "sideClick")
    check("side click flips card", page.locator(".flip.flipped").count() == 1)
    shot(page, "06-flash-back")
    hw(page, "scrollUp")  # Again -> requeued
    n = 0
    while "Cards" in page.inner_text("#barTitle") and n < 30:
        hw(page, "sideClick"); hw(page, "sideClick"); n += 1
    check("flashcards complete into quiz", "Quiz" in page.inner_text("#barTitle"))
    shot(page, "07-quiz")

    # ---- quiz via hardware: select first option with wheel, confirm ----
    qcount = 0
    while "Quiz" in page.inner_text("#barTitle") and qcount < 10:
        if qcount == 1: shot(page, "08-quiz-ar-options")
        # answer correctly by finding the right option text in app state
        hw(page, "scrollDown")
        page.evaluate("""() => {
          const opts=[...document.querySelectorAll('.opt')];
          const s = window.__kallimni.state; }""")
        hw(page, "sideClick"); page.wait_for_timeout(2600); qcount += 1
    check("quiz finishes on result screen", page.locator(".score").count() == 1)
    shot(page, "09-done")
    prog = page.evaluate("window.__kallimni.state.progress.l1")
    check("lesson marked completed with score", prog and prog["completed"], str(prog))
    check("streak started", page.evaluate("window.__kallimni.state.streak.count") == 1)
    page.wait_for_timeout(500)
    check("all storage writes were Base64", page.evaluate("window.__r1.badWrites") == 0)

    # ---- persistence across reload ----
    page.reload(); page.wait_for_timeout(700)
    check("progress survives reload (R1 storage)", "✓" in page.inner_text(".lesson[data-id=l1] .badge"))
    check("music preference remembered", page.evaluate("KMusic.state.enabled") and abs(page.evaluate("KMusic.state.volume") - 0.30) < 1e-6)
    check("music does not autoplay before a tap", page.evaluate("KMusic._audio.paused"))
    page.mouse.click(120, 270); page.wait_for_timeout(600)
    check("music resumes on first tap", not page.evaluate("KMusic._audio.paused"))
    check("today's lesson advanced to lesson 2", "Done today" in page.inner_text(".today") or "Polite" in page.inner_text(".today"))
    shot(page, "10-home-after")

    # settings
    page.click("#setBtn"); page.wait_for_timeout(150)
    shot(page, "11-settings")
    check("settings states no pronunciation scoring", "does not listen" in page.inner_text("#view"))
    check("no JS errors", not errors, "; ".join(errors[:3]))

    # ---- no-voice device: R1 voice fallback (opt-in) ----
    ctx2 = browser.new_context(viewport={"width": 240, "height": 282})
    ctx2.add_init_script("window.__fakeVoice=false;" + R1_STUBS + "Object.defineProperty(window,'speechSynthesis',{value:undefined});")
    pg = ctx2.new_page(); pg.goto(URL); pg.wait_for_timeout(400)
    pg.click(".lesson[data-id=l3]"); pg.click("#play"); pg.wait_for_timeout(200)
    check("no voice: honest toast, nothing posted", "No Arabic voice" in pg.inner_text("#toast") and pg.evaluate("window.__r1.posted.length") == 0)
    pg.evaluate("KSpeech.configure({r1Voice:true})"); pg.click("#play"); pg.wait_for_timeout(200)
    msg = pg.evaluate("window.__r1.posted[0]")
    check("R1 voice opt-in posts wantsR1Response message", msg and msg["wantsR1Response"] and "اسمك" in msg["message"], str(msg))
    shot(pg, "12-no-voice")

    # ---- empty playlist (shipped state) ----
    ctx3 = browser.new_context(viewport={"width": 240, "height": 282})
    pg3 = ctx3.new_page(); pg3.goto(URL); pg3.wait_for_timeout(400)
    check("plain browser falls back to localStorage", pg3.evaluate("KStore.backend") == "local")
    pg3.click("#musicBtn"); pg3.wait_for_timeout(150)
    check("empty playlist shows licensing note", "licensed" in pg3.inner_text("#view"))
    shot(pg3, "13-music-empty")

    browser.close()
srv.shutdown()
fails = [r for r in results if not r[1]]
print(f"\n{len(results) - len(fails)}/{len(results)} checks passed")
sys.exit(1 if fails else 0)
