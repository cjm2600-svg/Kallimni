# Kallimni daily curriculum agent (review-only)

## Current state
Prepared locally. No repository, GitHub Actions schedule, hosting, or paid AI service has been activated. The draft agent uses a **finite, pre-curated** queue (2 example lessons), not an AI generator. Those examples need review by an Egyptian Arabic speaker before publication. After those two are proposed, the agent safely stops until the candidate queue is replenished. Therefore **this is not yet indefinite autonomous content generation**.

## Operation
- On GitHub, `.github/workflows/draft-daily-lesson.yml` is designed to run daily at 14:00 UTC (not fixed local clock time) and open or update a PR, never merge it.
- GitHub repo Actions permissions must permit PR creation. Default `GITHUB_TOKEN` behavior depends on repository/org settings; workflow may require enabling “Allow GitHub Actions to create and approve pull requests.” Do not grant broad permissions beyond what's necessary.
- The workflow edits only `lessons/catalog.json`. Nothing touches Atlas.
- Reviewers must check dialect, gender, transliteration, and cultural context before merging.
- Merging a PR changes the catalog on the branch. Public availability additionally requires an approved hosting/deployment configuration.
- The app fetches `lessons/catalog.json` when opened. If fetch fails, built-in lessons continue working. No learner progress is uploaded.

## Local test
`python -m unittest discover -s agent -p 'test_*.py'`
`python agent/draft.py` (changes local catalog; use a clean git branch or a copy)
`python3 -m http.server 8000` then visit the app in a browser.

## Next phase
Implement AI candidate generation using a provider approved for cost/privacy and an independent quality-review process. Keep human approval mandatory before publishing. Never put API keys in the browser or repository.
